import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:gal/gal.dart'; // Для сохранения в галерею

List<CameraDescription> cameras = [];

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    cameras = await availableCameras();
  } catch (e) {
    print('Камера не найдена: $e');
  }
  runApp(const Xiaomi14UltraCamera());
}

class Xiaomi14UltraCamera extends StatelessWidget {
  const Xiaomi14UltraCamera({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const CameraMainScreen(),
    );
  }
}

class CameraMainScreen extends StatefulWidget {
  const CameraMainScreen({Key? key}) : super(key: key);

  @override
  _CameraMainScreenState createState() => _CameraMainScreenState();
}

class _CameraMainScreenState extends State<CameraMainScreen> {
  CameraController? controller;
  String currentMode = 'ФОТО';
  String currentZoom = '1x';
  bool isRecording = false;
  
  // Режимы стабилизации: 'off', 'steady', 'steady_pro'
  String stabilizationMode = 'off'; 

  final List<String> modes = ['ПРО', 'ВИДЕО', 'ФОТО', 'ПОРТРЕТ'];
  final Map<String, double> zoomValues = {
    '0.6x': 1.0, // Уменьшение зума (ультраширокий угол, если поддерживается)
    '1x': 2.0,
    '2x': 4.0,
    '5x': 10.0,
  };

  @override
  void initState() {
    super.initState();
    initCamera();
  }

  void initCamera() async {
    if (cameras.isEmpty) return;
    
    // Выбираем основную заднюю камеру
    controller = CameraController(
      cameras[0], 
      ResolutionPreset.max,
      enableAudio: true,
    );

    try {
      await controller!.initialize();
      // По умолчанию выставляем стандартный зум
      await controller!.setZoomLevel(zoomValues['1x']!);
      if (mounted) setState(() {});
    } catch (e) {
      print('Ошибка инициализации: $e');
    }
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  // Изменение зума
  void changeZoom(String zoomKey) async {
    if (controller == null || !controller!.value.isInitialized) return;
    setState(() => currentZoom = zoomKey);
    try {
      await controller!.setZoomLevel(zoomValues[zoomKey]!);
    } catch (e) {
      print('Ошибка зума: $e');
    }
  }

  // Переключение режимов стабилизации ShotSteady
  void toggleStabilization(String type) async {
    if (controller == null || !controller!.value.isInitialized) return;
    
    setState(() {
      if (stabilizationMode == type) {
        stabilizationMode = 'off';
      } else {
        stabilizationMode = type;
      }
    });

    try {
      if (stabilizationMode == 'off') {
        await controller!.setVideoStabilizationMode(VideoStabilizationMode.off);
      } else if (stabilizationMode == 'steady') {
        // Обычный ShotSteady (стандартная стабилизация)
        await controller!.setVideoStabilizationMode(VideoStabilizationMode.standard);
      } else if (stabilizationMode == 'steady_pro') {
        // ShotSteady Pro (максимально агрессивная стабилизация)
        await controller!.setVideoStabilizationMode(VideoStabilizationMode.cinematic);
      }
    } catch (e) {
      print('Стабилизация не поддерживается этим объективом: $e');
    }
  }

  // Съемка Фото или Видео
  void captureAction() async {
    if (controller == null || !controller!.value.isInitialized) return;

    if (currentMode == 'ФОТО') {
      try {
        final XFile file = await controller!.takePicture();
        await Gal.putImage(file.path); // Сохраняем в галерею
        showToast('Фото сохранено в Галерею');
      } catch (e) {
        showToast('Ошибка съемки: $e');
      }
    } else if (currentMode == 'ВИДЕО') {
      try {
        if (isRecording) {
          final XFile file = await controller!.stopVideoRecording();
          setState(() => isRecording = false);
          await Gal.putVideo(file.path); // Сохраняем видео в галерею
          showToast('Видео сохранено в Галерею');
        } else {
          await controller!.startVideoRecording();
          setState(() => isRecording = true);
        }
      } catch (e) {
        showToast('Ошибка видео: $e');
      }
    }
  }

  void showToast(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), duration: const Duration(seconds: 2)));
  }

  @override
  Widget build(BuildContext context) {
    final bool isCameraReady = controller != null && controller!.value.isInitialized;

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            // Верхняя панель Leica + Кнопки стабилизации ShotSteady
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('LEICA', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.amber, fontSize: 16, letterSpacing: 1.5)),
                  
                  // Кнопка ShotSteady
                  GestureDetector(
                    onTap: () => toggleStabilization('steady'),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: stabilizationMode == 'steady' ? Colors.amber : Colors.white10,
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Text('ShotSteady', style: TextStyle(fontSize: 11, color: stabilizationMode == 'steady' ? Colors.black : Colors.white, fontWeight: FontWeight.bold)),
                    ),
                  ),

                  // Кнопка ShotSteady Pro
                  GestureDetector(
                    onTap: () => toggleStabilization('steady_pro'),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: stabilizationMode == 'steady_pro' ? Colors.amber : Colors.white10,
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Text('ShotSteady PRO', style: TextStyle(fontSize: 11, color: stabilizationMode == 'steady_pro' ? Colors.black : Colors.white, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  
                  const Icon(Icons.menu, color: Colors.white),
                ],
              ),
            ),

            // Экран Живого Видоискателя
            Expanded(
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 4),
                clipBehavior: Clip.antiAlias,
                decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(16)),
                child: isCameraReady 
                    ? AspectRatio(aspectRatio: controller!.value.aspectRatio, child: CameraPreview(controller!))
                    : const Center(child: CircularProgressIndicator(color: Colors.amber)),
              ),
            ),

            // Блок интерфейса управления Xiaomi 14 Ultra
            Container(
              padding: const EdgeInsets.symmetric(vertical: 12),
              color: Colors.black,
              child: Column(
                children: [
                  // Переключатели ЗУМА (Включая 0.6x уменьшение)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: zoomValues.keys.map((zoomKey) {
                      bool isSelected = currentZoom == zoomKey;
                      return GestureDetector(
                        onTap: () => changeZoom(zoomKey),
                        child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 6),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: isSelected ? Colors.white24 : Colors.transparent,
                            shape: BoxShape.circle,
                          ),
                          child: Text(zoomKey, style: TextStyle(color: isSelected ? Colors.amber : Colors.white60, fontSize: 12, fontWeight: FontWeight.bold)),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 12),

                  // Карусель режимов (ФОТО / ВИДЕО)
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: modes.map((mode) {
                        bool isSelected = currentMode == mode;
                        return GestureDetector(
                          onTap: () {
                            if (!isRecording) setState(() => currentMode = mode);
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: Text(mode, style: TextStyle(color: isSelected ? Colors.white : Colors.white38, fontSize: 14, fontWeight: isSelected ? FontWeight.bold : FontWeight.normal)),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Кнопка съемки
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const Icon(Icons.image, color: Colors.white30, size: 28),
                      
                      // Центральный Кнопка-Затвор
